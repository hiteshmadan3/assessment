
package com.banking.model;

public class User {

    private String customerId;
    private String name;
    private String surname;

    public User(String customerId, String name, String surname) {
        this.customerId = customerId;
        this.name = name;
        this.surname = surname;
    }

    public String getCustomerId() {
        return customerId;
    }

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }
}
