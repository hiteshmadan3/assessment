
package com.banking.model;

import java.util.ArrayList;
import java.util.List;

public class Account {

    private User user;
    private double balance;
    private List<Transaction> transactions;

    public Account(User user, double balance) {
        this.user = user;
        this.balance = balance;
        this.transactions = new ArrayList<>();
    }

    public User getUser() {
        return user;
    }

    public double getBalance() {
        return balance;
    }

    public List<Transaction> getTransactions() {
        return transactions;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
}
