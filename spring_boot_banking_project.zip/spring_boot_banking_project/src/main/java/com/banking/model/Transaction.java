
package com.banking.model;

public class Transaction {

    private String customerId;
    private double amount;

    public Transaction(String customerId, double amount) {
        this.customerId = customerId;
        this.amount = amount;
    }

    public String getCustomerId() {
        return customerId;
    }

    public double getAmount() {
        return amount;
    }

    @Override
    public String toString() {
        return "Transaction{customerId='" + customerId + "', amount=" + amount + "}";
    }
}
