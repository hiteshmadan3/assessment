
package com.banking.repository;

import com.banking.model.Account;
import org.springframework.stereotype.Repository;
import java.util.HashMap;
import java.util.Map;

@Repository
public class AccountRepository {

    private Map<String, Account> accounts = new HashMap<>();

    public void save(Account account) {
        accounts.put(account.getUser().getCustomerId(), account);
    }

    public Account findByCustomerId(String customerId) {
        return accounts.get(customerId);
    }
}
