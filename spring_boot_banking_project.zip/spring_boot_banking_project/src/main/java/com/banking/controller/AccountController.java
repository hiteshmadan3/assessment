
package com.banking.controller;

import com.banking.service.AccountService;
import com.banking.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    @Autowired
    private AccountService accountService;

    @Autowired
    private TransactionService transactionService;

    @PostMapping("/open")
    public String openAccount(@RequestParam String customerId, @RequestParam double initialCredit) {
        String accountCreationResponse = accountService.openAccount(customerId, initialCredit);
        if (initialCredit != 0) {
            transactionService.addTransaction(customerId, initialCredit);
        }
        return accountCreationResponse;
    }

    @GetMapping("/{customerId}")
    public String getAccountInfo(@PathVariable String customerId) {
        return accountService.getAccountInfo(customerId);
    }
}
