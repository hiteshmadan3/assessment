
package com.banking.controller;

import com.banking.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    @Autowired
    private TransactionService transactionService;

    @PostMapping("/add")
    public String addTransaction(@RequestParam String customerId, @RequestParam double amount) {
        return transactionService.addTransaction(customerId, amount);
    }

    @GetMapping("/{customerId}")
    public String getTransactions(@PathVariable String customerId) {
        return transactionService.getTransactions(customerId);
    }
}
