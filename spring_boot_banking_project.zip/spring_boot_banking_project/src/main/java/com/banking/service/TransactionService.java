
package com.banking.service;

import com.banking.repository.AccountRepository;
import com.banking.repository.TransactionRepository;
import com.banking.model.Account;
import com.banking.model.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TransactionService {

    @Autowired
    private AccountRepository accountRepository;

    @Autowired
    private TransactionRepository transactionRepository;

    public String addTransaction(String customerId, double amount) {
        Account account = accountRepository.findByCustomerId(customerId);
        if (account != null) {
            account.setBalance(account.getBalance() + amount);
            Transaction transaction = new Transaction(customerId, amount);
            transactionRepository.save(transaction);
            account.getTransactions().add(transaction);
            return "Transaction added for " + customerId + ". Amount: " + amount;
        } else {
            return "Account not found for customer: " + customerId;
        }
    }
}
