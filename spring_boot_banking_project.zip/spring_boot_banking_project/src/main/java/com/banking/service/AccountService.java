
package com.banking.service;

import com.banking.repository.AccountRepository;
import com.banking.model.Account;
import com.banking.model.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountService {

    @Autowired
    private AccountRepository accountRepository;

    public String openAccount(String customerId, double initialCredit) {
        User user = new User(customerId, "John", "Doe"); // Assuming static user info for now
        Account account = new Account(user, initialCredit);
        accountRepository.save(account);
        return "Account opened for " + user.getName() + " " + user.getSurname() + " with balance: " + initialCredit;
    }

    public String getAccountInfo(String customerId) {
        Account account = accountRepository.findByCustomerId(customerId);
        if (account != null) {
            return "Name: " + account.getUser().getName() + " " + account.getUser().getSurname() +
                    ", Balance: " + account.getBalance() + ", Transactions: " + account.getTransactions().toString();
        } else {
            return "Account not found";
        }
    }
}
