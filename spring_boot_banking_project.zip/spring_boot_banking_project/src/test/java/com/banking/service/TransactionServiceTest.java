
package com.banking.service;

import com.banking.repository.AccountRepository;
import com.banking.repository.TransactionRepository;
import com.banking.model.Account;
import com.banking.model.Transaction;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class TransactionServiceTest {

    private TransactionService transactionService;
    private AccountRepository accountRepository;
    private TransactionRepository transactionRepository;

    @BeforeEach
    public void setup() {
        accountRepository = Mockito.mock(AccountRepository.class);
        transactionRepository = Mockito.mock(TransactionRepository.class);
        transactionService = new TransactionService();
        transactionService.accountRepository = accountRepository;
        transactionService.transactionRepository = transactionRepository;
    }

    @Test
    public void testAddTransaction() {
        Account account = new Account(new User("123", "John", "Doe"), 500.0);
        Mockito.when(accountRepository.findByCustomerId("123")).thenReturn(account);

        String result = transactionService.addTransaction("123", 100.0);
        assertEquals("Transaction added for 123. Amount: 100.0", result);
    }
}
