
package com.banking.controller;

import com.banking.service.TransactionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
public class TransactionControllerTest {

    @Autowired
    private TransactionService transactionService;

    private MockMvc mockMvc;

    @Test
    public void testAddTransaction() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(new TransactionController(transactionService)).build();
        mockMvc.perform(post("/transactions/add?customerId=123&amount=500.0"))
                .andExpect(status().isOk());
    }

    @Test
    public void testGetTransactions() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(new TransactionController(transactionService)).build();
        mockMvc.perform(get("/transactions/123"))
                .andExpect(status().isOk());
    }
}
