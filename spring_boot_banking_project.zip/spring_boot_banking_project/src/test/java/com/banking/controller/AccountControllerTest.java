
package com.banking.controller;

import com.banking.service.AccountService;
import com.banking.service.TransactionService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

@SpringBootTest
public class AccountControllerTest {

    @Autowired
    private AccountService accountService;

    @Autowired
    private TransactionService transactionService;

    private MockMvc mockMvc;

    @Test
    public void testOpenAccount() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(new AccountController(accountService, transactionService)).build();
        mockMvc.perform(post("/accounts/open?customerId=123&initialCredit=500.0"))
                .andExpect(status().isOk())
                .andExpect(content().string("Account opened for John Doe with balance: 500.0"));
    }

    @Test
    public void testGetAccountInfo() throws Exception {
        mockMvc = MockMvcBuilders.standaloneSetup(new AccountController(accountService, transactionService)).build();
        mockMvc.perform(get("/accounts/123"))
                .andExpect(status().isOk())
                .andExpect(content().string("Name: John Doe, Balance: 500.0, Transactions: []"));
    }
}
